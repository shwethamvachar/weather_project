function fetchWeather() {
    const location = document.getElementById('location').value;
    fetch(`/weather/${location}`)
        .then(response => response.json())
        .then(data => {
            const weatherInfoElement = document.getElementById('weather-info');
            weatherInfoElement.innerHTML = `
                <p>Location: ${data.name}</p>
                <p>Temperature: ${data.temperature}°C</p>
                <p>Description: ${data.description}</p>
                
            `;
        })
        .catch(error => console.error('Error fetching weather:', error));
}
function handlePageLoad() {
    const defaultCity = 'Bangalore'; // Replace with your desired default city
    document.getElementById('location').value = defaultCity; // Set the input field value
    fetchWeather(defaultCity); // Fetch and display weather data for the default city
}

function resetWeather() {
    const weatherInfoElement = document.getElementById('weather-info');
    weatherInfoElement.innerHTML = ''; // Clear weather information

    const defaultCity = 'Bangalore'; // Replace with your desired default city
    document.getElementById('location').value = defaultCity; // Reset input field to default city
    fetchWeather(defaultCity); // Fetch and display weather data for the default city
}
// Call the handlePageLoad function when the page loads
window.onload = handlePageLoad;